Open SCENARIO folder, run Scenario.cmd file in a cmd prompt. 
If running on a named instance, then also use the instance name as parameter to Scenario.cmd file.
Follow the video steps (no audio).