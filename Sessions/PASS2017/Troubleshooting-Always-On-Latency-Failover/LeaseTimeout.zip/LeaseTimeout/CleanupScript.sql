:Connect Node5

Drop Availability Group LeaseTimeoutDemo
Go
ALTER EVENT SESSION [LeaseTimeoutEvents] ON SERVER STATE = STOP;  
GO  
ALTER EVENT SESSION [AlwaysOn_Health] ON SERVER STATE = STOP;  
GO  
:Connect Node4

ALTER EVENT SESSION [AlwaysOn_Health] ON SERVER STATE = start;  
GO  
Drop Database [DB1]
Go