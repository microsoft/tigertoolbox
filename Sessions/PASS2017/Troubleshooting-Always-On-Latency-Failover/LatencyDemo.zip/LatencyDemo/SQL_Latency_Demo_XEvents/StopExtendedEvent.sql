-- Extended event session definition to track AlwaysOn latency
-- These events can be very noisy and it is not recommended to capture these events continuously on production instances
-- This event would need to be started on all the Availability Group replicas

:CONNECT NODE1

ALTER EVENT SESSION [AlwaysOn_Data_Movement_Tracing] ON SERVER STATE=STOP
GO


:CONNECT NODE2

ALTER EVENT SESSION [AlwaysOn_Data_Movement_Tracing] ON SERVER STATE=STOP
GO


:CONNECT NODE3


ALTER EVENT SESSION [AlwaysOn_Data_Movement_Tracing] ON SERVER STATE=STOP
GO