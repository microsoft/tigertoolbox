select Number from
	(
	select row_number() over (order by s1.name) as number
	from sys.sysobjects s1
	cross apply sys.sysobjects s2
	cross apply sys.sysobjects s3
	cross apply sys.sysobjects s4
	cross apply sys.sysobjects s5
	) as InnerNumbersTable