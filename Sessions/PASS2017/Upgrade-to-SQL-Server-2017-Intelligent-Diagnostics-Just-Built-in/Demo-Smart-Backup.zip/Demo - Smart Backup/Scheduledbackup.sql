SET NOCOUNT ON
WHILE(1=1)
BEGIN

BACKUP LOG [PowerConsumption] to disk = 'C:\Program Files\Microsoft SQL Server\MSSQL14.SQL2017\MSSQL\Backup\powerconsumption.trn' WITH FORMAT,COMPRESSION
WAITFOR DELAY '00:01:00'
END

