USE [master];
GO
ALTER DATABASE [AdventureworksDW2016CTP3]
SET QUERY_STORE (	OPERATION_MODE = READ_WRITE, 
					DATA_FLUSH_INTERVAL_SECONDS = 60, 
					QUERY_CAPTURE_MODE = ALL,
					INTERVAL_LENGTH_MINUTES = 1);
GO

USE [AdventureworksDW2016CTP3];
GO
ALTER DATABASE CURRENT SET QUERY_STORE CLEAR ALL;
GO

-- Next open up a separate window and execute the following
USE [AdventureworksDW2016CTP3];
GO

BEGIN TRANSACTION

DELETE fis
FROM [dbo].[FactInternetSales] fis
INNER JOIN [dbo].[DimProduct] dp ON fis.ProductKey = dp.ProductKey
WHERE dp.EnglishProductName = 'Touring Tire' AND SalesTerritoryKey = 10;

-- Hold off on rolling back until after the block
ROLLBACK TRANSACTION

-- Now back in this window, execute the following
SELECT SUM(SalesAmount)
FROM [dbo].[FactInternetSales] fis
INNER JOIN [dbo].[DimProduct] dp ON fis.ProductKey = dp.ProductKey
WHERE dp.EnglishProductName = 'Touring Tire';

-- After a few seconds - roll back the other transaction
-- Repeat

EXECUTE sp_query_store_flush_db;

-- Show UI XP




-- Resume
SELECT [q].[query_id], *
FROM sys.query_store_query_text AS [t]
INNER JOIN sys.query_store_query AS [q]
	ON [t].query_text_id = [q].query_text_id
WHERE query_sql_text LIKE '%SELECT SUM(%';


SELECT plan_id
FROM sys.query_store_plan
WHERE query_id = 2;


SELECT *
FROM sys.query_store_wait_stats
WHERE	plan_id = 2 AND
		wait_category_desc NOT IN ('Unknown')
ORDER BY avg_query_wait_time_ms DESC;


-- Reset
USE [master]
GO
ALTER DATABASE [AdventureworksDW2016CTP3] SET QUERY_STORE = OFF
GO
