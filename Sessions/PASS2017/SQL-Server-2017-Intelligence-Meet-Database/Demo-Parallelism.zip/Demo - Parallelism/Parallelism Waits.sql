USE [AdventureWorks2016CTP3]
GO

-- Remember to set Actual showplan

-- waits in Showplan
SELECT *
FROM Sales.SalesOrderDetail SOD
INNER JOIN Production.Product P ON SOD.ProductID = P.ProductID
WHERE SalesOrderDetailID > 10
ORDER BY Style
GO






-- Reducing CXPacket waits?
SELECT *
FROM Sales.SalesOrderDetail SOD
INNER JOIN Production.Product P ON SOD.ProductID = P.ProductID
WHERE SalesOrderDetailID > 10
ORDER BY Style
OPTION (MAXDOP 4)
--OPTION (MAXDOP 4, MIN_GRANT_PERCENT = 10)
GO




-- note on spill above in row mode - mem grant feedback works for batch mode only.


-- See CX wait distribution

--Clear the current stats to start afresh
DBCC SQLPERF("sys.dm_os_wait_stats" , CLEAR)
GO

--Verify that the waitstats have been cleared
SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

SELECT *
FROM Sales.SalesOrderDetail SOD
INNER JOIN Production.Product P ON SOD.ProductID = P.ProductID
WHERE SalesOrderDetailID > 10
ORDER BY Style
GO

SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO



-- See CX wait split?

--Clear the current stats to start afresh
DBCC SQLPERF("sys.dm_os_wait_stats" , CLEAR)
GO


--Verify that the waitstats have been cleared
SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

SELECT *
FROM Sales.SalesOrderDetail SOD
INNER JOIN Production.Product P ON SOD.ProductID = P.ProductID
WHERE SalesOrderDetailID > 10
ORDER BY Style
OPTION (MAXDOP 4, MIN_GRANT_PERCENT = 10)
GO

SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO


------------------------------------------------------------------------------


ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE
GO

-- Another example. What can be done?

-- Remember to set Actual showplan


USE [AdventureWorks2016CTP3]
GO

-- Remember to set Actual showplan


--Clear the current stats to start afresh
DBCC SQLPERF("sys.dm_os_wait_stats" , CLEAR)
GO

--Verify that the waitstats have been cleared
SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

SELECT t1.*
FROM 
	(SELECT TOP 150000 SOD.*
	FROM Sales.SalesOrderDetail SOD
	INNER JOIN Production.Product P ON SOD.ProductID = P.ProductID
	WHERE SalesOrderDetailID > 10) t1
INNER JOIN Sales.SalesOrderHeaderBulk SOH ON t1.SalesOrderID = SOH.SalesOrderID
WHERE SOH.SalesOrderID > 1
GO

SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

/*
Track waits:

*/

-- Eliminate the TOP 150000 - we get fewer rows anyway

--Clear the current stats to start afresh
DBCC SQLPERF("sys.dm_os_wait_stats" , CLEAR)
GO

--Verify that the waitstats have been cleared
SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

SELECT t1.*
FROM 
	(SELECT SOD.*
	FROM Sales.SalesOrderDetail SOD
	INNER JOIN Production.Product P ON SOD.ProductID = P.ProductID
	WHERE SalesOrderDetailID > 10) t1
INNER JOIN Sales.SalesOrderHeaderBulk SOH ON t1.SalesOrderID = SOH.SalesOrderID
WHERE SOH.SalesOrderID > 1
go

SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

/*
Track waits:

*/


-- Ok, that removes non parallel areas of the plan and improves a lot. 
-- But let's say we needed the TOP?

--Clear the current stats to start afresh
DBCC SQLPERF("sys.dm_os_wait_stats" , CLEAR)
GO

--Verify that the waitstats have been cleared
SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

SELECT TOP 150000 SOD.*
FROM Sales.SalesOrderDetail SOD
INNER JOIN Sales.SalesOrderHeaderBulk SOH ON SOD.SalesOrderID = SOH.SalesOrderID
INNER JOIN Production.Product P ON SOD.ProductID = P.ProductID
WHERE SalesOrderDetailID > 10 AND SOH.SalesOrderID > 1
OPTION (MAXDOP 4)
go

SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

/*
Track waits:

*/

-- This moved the Top from the middle of the plan, and still reduces the waits when compared to original.
-- Can we do better?

--Clear the current stats to start afresh
DBCC SQLPERF("sys.dm_os_wait_stats" , CLEAR)
GO

--Verify that the waitstats have been cleared
SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

-- Let's limit DOP (was running at DOP 12)
SELECT TOP 150000 SOD.*
FROM Sales.SalesOrderDetail SOD
INNER JOIN Sales.SalesOrderHeaderBulk SOH ON SOD.SalesOrderID = SOH.SalesOrderID
INNER JOIN Production.Product P ON SOD.ProductID = P.ProductID
WHERE SalesOrderDetailID > 10 AND SOH.SalesOrderID > 1
OPTION (MAXDOP 4)
go

SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

/*
Track waits:

*/

-- Done - Troubleshooting with wait types.











/*
Bitmap filtering speeds up query execution by eliminating rows with key values that cannot produce any join records 
before passing rows through another operator such as the Parallelism operator. 
*/