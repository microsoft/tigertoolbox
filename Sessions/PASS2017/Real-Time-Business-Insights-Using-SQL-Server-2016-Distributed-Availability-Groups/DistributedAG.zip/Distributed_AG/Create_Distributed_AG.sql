/*
SCRIPT TO CREATE A DISTRIBUTED AVAILABILITY GROUP
*/

/****************************************************************************
STEP 1 - Create the Primary Availability Group
****************************************************************************/
--- Connect to the Primary Replica of the Primary AG

:Connect Node1 

USE [master]
GO

/****** Object:  Endpoint [Hadr_endpoint]    Script Date: 10/27/2017 1:19:53 AM ******/
CREATE ENDPOINT [Hadr_endpoint] 
	STATE=STARTED
	AS TCP (LISTENER_PORT = 5022, LISTENER_IP = ALL)   /*Ensure the Endpoint is configured to listen on all Ports */
	FOR DATA_MIRRORING (ROLE = ALL, AUTHENTICATION = WINDOWS NEGOTIATE
, ENCRYPTION = REQUIRED ALGORITHM AES)
GO

-- Create the Availability Group
CREATE AVAILABILITY GROUP [LatencyDemo]
FOR DATABASE [DB1]
REPLICA ON 'Node1'
WITH (ENDPOINT_URL = N'TCP://Node1.napster.com:5022', 
		 FAILOVER_MODE = AUTOMATIC, 
		 AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, 
		 BACKUP_PRIORITY = 50, 
		 SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL), 
		 SEEDING_MODE = AUTOMATIC),
N'Node2' WITH (ENDPOINT_URL = N'TCP://Node2.napster.com:5022', 
	 FAILOVER_MODE = AUTOMATIC, 
	 AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, 
	 BACKUP_PRIORITY = 50, 
	 SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL), 
	 SEEDING_MODE = AUTOMATIC);
 GO

:Connect Node2 

USE [master]
GO

/****** Object:  Endpoint [Hadr_endpoint]    Script Date: 10/27/2017 1:19:53 AM ******/
CREATE ENDPOINT [Hadr_endpoint] 
	STATE=STARTED
	AS TCP (LISTENER_PORT = 5022, LISTENER_IP = ALL)   /*Ensure the Endpoint is configured to listen on all Ports */
	FOR DATA_MIRRORING (ROLE = ALL, AUTHENTICATION = WINDOWS NEGOTIATE
, ENCRYPTION = REQUIRED ALGORITHM AES)
GO

ALTER AVAILABILITY GROUP [LatencyDemo] JOIN
GO  
ALTER AVAILABILITY GROUP [LatencyDemo] GRANT CREATE ANY DATABASE
Go

--- Create the Listener for the Availability Group. This is very important.******

:Connect Node1

USE [master]
GO
ALTER AVAILABILITY GROUP [LatencyDemo]
ADD LISTENER N'LatencyDemoList' (
WITH IP
((N'10.1.0.25', N'255.255.255.0'),
(N'10.2.0.25', N'255.255.255.0')
)
, PORT=1500);
GO

/****************************************************************************
STEP 2 - Create the Secondary Availability Group
****************************************************************************/
--- Connect to the Primary Replica of the Secondary AG

:Connect Node4

USE [master]
GO

/****** Object:  Endpoint [Hadr_endpoint]    Script Date: 10/27/2017 1:19:53 AM ******/
CREATE ENDPOINT [Hadr_endpoint] 
	STATE=STARTED
	AS TCP (LISTENER_PORT = 5022, LISTENER_IP = ALL)   /*Ensure the Endpoint is configured to listen on all Ports */
	FOR DATA_MIRRORING (ROLE = ALL, AUTHENTICATION = WINDOWS NEGOTIATE
, ENCRYPTION = REQUIRED ALGORITHM AES)
GO

-- Create the Availability Group
CREATE AVAILABILITY GROUP [LeaseTimeoutDemo]
FOR
REPLICA ON 'Node4'
WITH (ENDPOINT_URL = N'TCP://Node4.napster.com:5022', 
		 FAILOVER_MODE = AUTOMATIC, 
		 AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, 
		 BACKUP_PRIORITY = 50, 
		 SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL), 
		 SEEDING_MODE = AUTOMATIC),
N'Node5' WITH (ENDPOINT_URL = N'TCP://Node5.napster.com:5022', 
	 FAILOVER_MODE = AUTOMATIC, 
	 AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, 
	 BACKUP_PRIORITY = 50, 
	 SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL), 
	 SEEDING_MODE = AUTOMATIC);
 GO

:Connect Node5

USE [master]
GO

/****** Object:  Endpoint [Hadr_endpoint]    Script Date: 10/27/2017 1:19:53 AM ******/
CREATE ENDPOINT [Hadr_endpoint] 
	STATE=STARTED
	AS TCP (LISTENER_PORT = 5022, LISTENER_IP = ALL)   /*Ensure the Endpoint is configured to listen on all Ports */
	FOR DATA_MIRRORING (ROLE = ALL, AUTHENTICATION = WINDOWS NEGOTIATE
, ENCRYPTION = REQUIRED ALGORITHM AES)
GO

ALTER AVAILABILITY GROUP [LeaseTimeoutDemo] JOIN
GO  
ALTER AVAILABILITY GROUP [LeaseTimeoutDemo] GRANT CREATE ANY DATABASE
Go

--- Create the Listener for the Availability Group. This is very important.******
:Connect Node4

USE [master]
GO
ALTER AVAILABILITY GROUP [LeaseTimeoutDemo]
ADD LISTENER N'LeaseTimeList' (
WITH IP
((N'10.1.0.26', N'255.255.255.0'),
(N'10.2.0.26', N'255.255.255.0')
)
, PORT=1500);
GO

/****************************************************************************
STEP 3 - Create the Distributed Availability Group
****************************************************************************/
-- Connect to the Primary Replica of the Primary Availability Group
:Connect Node1
CREATE AVAILABILITY GROUP [DistributedAG]
WITH (DISTRIBUTED)
AVAILABILITY GROUP ON 'LatencyDemo' WITH
(�LISTENER_URL = 'tcp://LatencyDemoList:5022',
AVAILABILITY_MODE = SYNCHRONOUS_COMMIT,
FAILOVER_MODE = MANUAL,
SEEDING_MODE = AUTOMATIC�),
	'LeaseTimeoutDemo' WITH
(�LISTENER_URL = 'tcp://LeaseTimeList:5022',
AVAILABILITY_MODE = SYNCHRONOUS_COMMIT,
FAILOVER_MODE = MANUAL,
SEEDING_MODE =�AUTOMATIC );

--- Connect to the Primary Replica of the Secondary Availability Group
:Connect Node4

Alter AVAILABILITY GROUP [DistributedAG]
Join
AVAILABILITY GROUP ON 'LatencyDemo' WITH
(�LISTENER_URL = 'tcp://LatencyDemoList:5022',
AVAILABILITY_MODE = SYNCHRONOUS_COMMIT,
FAILOVER_MODE = MANUAL,
SEEDING_MODE = AUTOMATIC�),
	'LeaseTimeoutDemo' WITH
(�LISTENER_URL = 'tcp://LeaseTimeList:5022',
AVAILABILITY_MODE = SYNCHRONOUS_COMMIT,
FAILOVER_MODE = MANUAL,
SEEDING_MODE =�AUTOMATIC );
