USE WideWorldImporters
GO
DECLARE @packagetypeid int = 7;
EXEC dbo.report @packagetypeid
GO