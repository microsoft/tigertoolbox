--Available hints
SELECT * FROM sys.dm_exec_valid_use_hints
GO


USE [AdventureWorks2016CTP3]
GO

-- Very small number of rows expected even with new CE.
SELECT AddressID
FROM Person.[Address]
WHERE City = N'Ballard' AND [PostalCode] = '98107'
GO

-- Same query compiled with legacy CE
-- Cardinality estimate is expected to be greater than the new CE estimate
SELECT AddressID
FROM Person.[Address]
WHERE City = N'Ballard' AND [PostalCode] = '98107'
OPTION (USE HINT('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
GO

-- Same query compiled with legacy CE hint and legacy CE TF
SELECT AddressID
FROM Person.[Address]
WHERE City = N'Ballard' AND [PostalCode] = '98107'
OPTION (USE HINT('FORCE_LEGACY_CARDINALITY_ESTIMATION'), QUERYTRACEON 9481)
GO

----------------------------------------------------------------------
-- Can I?
-- Same query compiled with legacy CE hint and New CE TF
SELECT AddressID
FROM Person.[Address]
WHERE City = N'Ballard' AND [PostalCode] = '98107'
OPTION (USE HINT('FORCE_LEGACY_CARDINALITY_ESTIMATION'), QUERYTRACEON 2312)
GO

-- Same query compiled with default CE hint and legacy CE TF
SELECT AddressID
FROM Person.[Address]
WHERE City = N'Ballard' AND [PostalCode] = '98107'
OPTION (USE HINT('FORCE_DEFAULT_CARDINALITY_ESTIMATION'), QUERYTRACEON 9481)
GO

----------------------------------------------------------------------

-- Very small number of rows expected even with new CE.
SELECT AddressID
FROM Person.[Address]
WHERE City = N'Ballard' AND [PostalCode] = '98107'
GO

-- When estimating conjunction and/or disjunction of single-table filters, assume the most selective implies the others
-- Same query compiled with min selectivity use hint
SELECT AddressID
FROM Person.[Address]
WHERE City = N'Ballard' AND [PostalCode] = '98107'
OPTION (USE HINT('ASSUME_MIN_SELECTIVITY_FOR_FILTER_ESTIMATES'))
GO

----------------------------------------------------------------------

-- Same as new CE 9471?
-- Cardinality estimate with TF 4137 is expected to be greater than the default estimate 
-- Same query compiled with legacy CE and min selectivity TF (TF 4137) for old CE
SELECT AddressID
FROM Person.[Address]
WHERE City = N'Ballard' AND [PostalCode] = '98107'
OPTION (QUERYTRACEON 9481, QUERYTRACEON 4137)
GO

-- Same query compiled with legacy CE and min selectivity USE HINT for old CE
SELECT AddressID
FROM Person.[Address]
WHERE City = N'Ballard' AND [PostalCode] = '98107'
OPTION (USE HINT('FORCE_LEGACY_CARDINALITY_ESTIMATION', 'ASSUME_MIN_SELECTIVITY_FOR_FILTER_ESTIMATES'))
GO

----------------------------------------------------------------------

-- disable_optimizer_rowgoal use hint has the same effect to disable rowgoal TF(TF 4138)

-- 1 row expected due to TOP (1)
SELECT TOP (1) *
FROM Production.Product P 
INNER JOIN Production.TransactionHistory H ON H.ProductID = P.ProductID
GO

-- If rowgoal is disabled, hash match would be preferred to nested loop
SELECT TOP (1) *
FROM Production.Product P 
JOIN Production.TransactionHistory H ON H.ProductID = P.ProductID
OPTION (QUERYTRACEON 4138);
GO

-- Same query compiled with disable_optimizer_rowgoal use hint
SELECT TOP (1) *
FROM Production.Product P 
INNER JOIN Production.TransactionHistory H ON H.ProductID = P.ProductID
OPTION (USE HINT('DISABLE_OPTIMIZER_ROWGOAL'));
GO

----------------------------------------------------------------------

-- Smaller number of rows expected with new CE due to base containment assumption
SELECT [od].[SalesOrderID], [od].[SalesOrderDetailID]
FROM Sales.[SalesOrderDetail] AS [od]
INNER JOIN Production.[Product] AS [p] ON [od].[ProductID] = [p].[ProductID]
WHERE [p].[Color] = 'Red' AND [od].[ModifiedDate] = '2011-06-29 00:00:00.000'
GO

-- Assume_join_predicate_depends_on_filters use hint and simple containment TF (TF 9476)
-- Cardinality estimate with TF 9476 is expected to be greater than the default estimate.

-- Same query compiled with simple containment TF (TF 9476).
SELECT [od].[SalesOrderID], [od].[SalesOrderDetailID]
FROM Sales.[SalesOrderDetail] AS [od]
INNER JOIN Production.[Product] AS [p] ON [od].[ProductID] = [p].[ProductID]
WHERE [p].[Color] = 'Red' AND [od].[ModifiedDate] = '2011-06-29 00:00:00.000'
OPTION (QUERYTRACEON 9476)
GO

-- Same query compiled with simple containment use hint
SELECT [od].[SalesOrderID], [od].[SalesOrderDetailID]
FROM Sales.[SalesOrderDetail] AS [od]
INNER JOIN Production.[Product] AS [p] ON [od].[ProductID] = [p].[ProductID]
WHERE [p].[Color] = 'Red' AND [od].[ModifiedDate] = '2011-06-29 00:00:00.000'
OPTION (USE HINT('ASSUME_JOIN_PREDICATE_DEPENDS_ON_FILTERS'))
GO

---------------------------------------------------------

USE [AdventureWorksDW2016CTP3]
GO
-- New CE - good enough
SELECT * FROM FactInternetSales fis INNER JOIN DimProduct dp ON fis.ProductKey = dp.ProductKey
WHERE CurrencyKey = 98 AND SalesTerritoryKey = 10
GO

-- Legacy CE - not so good
SELECT * FROM FactInternetSales fis INNER JOIN DimProduct dp ON fis.ProductKey = dp.ProductKey
WHERE CurrencyKey = 98 AND SalesTerritoryKey = 10
OPTION (USE HINT('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
GO

-- New CE using minimum selectivity when estimating AND predicates for filters to account for correlation (4137 old CE and 9471 new CE)
SELECT * FROM FactInternetSales fis INNER JOIN DimProduct dp ON fis.ProductKey = dp.ProductKey
WHERE CurrencyKey = 98 AND SalesTerritoryKey = 10
OPTION (USE HINT('ASSUME_MIN_SELECTIVITY_FOR_FILTER_ESTIMATES'))
GO