USE AdventureWorks2016CTP3
GO
--DROP TABLE tblBadData
GO