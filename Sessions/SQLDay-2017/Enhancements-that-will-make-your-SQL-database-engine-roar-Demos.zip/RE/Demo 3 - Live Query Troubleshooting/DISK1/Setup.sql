IF DB_NAME() != 'AdventureWorks2016CTP3' 
USE AdventureWorks2016CTP3
SET NOCOUNT ON
GO
IF OBJECT_ID ('tblBadData', 'U') IS NOT NULL
BEGIN
    IF ((SELECT COUNT(*) FROM tblBadData) < 64000) DROP TABLE tblBadData
END
GO
DECLARE @maxRows int
SET @maxRows = 64000

IF OBJECT_ID ('tblBadData', 'U') IS NULL
BEGIN
    PRINT ''
    RAISERROR ('Setting up (one-time operation unless you drop the AdventureWorks2016CTP3 database)...', 0, 1) WITH NOWAIT
    PRINT ''
    CREATE TABLE tblBadData (c1 int IDENTITY, c2 char(7000))
    DECLARE @rows int
    DECLARE @updateInterval int
    DECLARE @pctComplete int
    SET @rows = 0
    SET @updateInterval = @maxRows / 40
    SET NOCOUNT ON
    BEGIN TRAN
    WHILE (@rows <= @maxRows)
    BEGIN
        INSERT INTO tblBadData (c2) VALUES (@rows)
        SET @rows = @rows + 1 
        IF (@rows % @updateInterval = 0) 
        BEGIN
            SET @pctComplete = @rows * 100 / @maxRows
            RAISERROR ('Inserting data (%d pct complete)...', 0, 1, @pctComplete) WITH NOWAIT
            COMMIT TRAN
            BEGIN TRAN
        END
    END
END
GO
WHILE (@@TRANCOUNT > 0) COMMIT TRAN
GO
IF NOT EXISTS (SELECT * FROM sysindexes WHERE id = OBJECT_ID ('tblBadData') AND [name] = 'idx1')
BEGIN
    RAISERROR ('Creating index...', 0, 1) WITH NOWAIT
    CREATE NONCLUSTERED INDEX idx1 ON tblBadData (c1)
END
GO
