CREATE DATABASE SmartDiffbackup;
GO
USE [SmartDiffbackup]
GO
DROP TABLE tbl_SelectIntoTest

CREATE TABLE tbl_SelectIntoTest
(
RecordID INT IDENTITY(1,1) NOT NULL,
FName CHAR(500),
LName CHAR(500),
City CHAR(7000),
DeptID INT NOT NULL
) ON [PRIMARY]
GO
�
CREATE CLUSTERED INDEX CIX_tbl_SelectIntoTest_RecordID ON tbl_SelectIntoTest(RecordID)
GO
�
DECLARE @Counter INT;
SET @Counter = 1;
�
SET NOCOUNT ON;
�
WHILE (@Counter<=10000)
BEGIN
	IF(@Counter%4=1)
		INSERT INTO tbl_SelectIntoTest VALUES('Satya','Nadella','Bellevue',2);
	ELSE IF(@Counter%4=2)
		INSERT INTO tbl_SelectIntoTest VALUES('Scott','Guthrie','Seattle',1);
	ELSE IF(@Counter%4=3)
		INSERT INTO tbl_SelectIntoTest VALUES('Joseph','Sirosh','Sammamish',3);
	ELSE
		INSERT INTO tbl_SelectIntoTest VALUES('Sudhakar','Sannakkayala','Seattle',4);
�
	SET @Counter = @Counter + 1;
END
�
USE [SmartDiffbackup]
GO
select CAST(ROUND((SUM(modified_extent_page_count)*100.0)/SUM(allocated_extent_page_count),2)
as decimal(9,2))
as '% Differential Changes since last backup'
from sys.dm_db_file_space_usage
GO


-- Take Full Database Backup to start a backup chain
BACKUP DATABASE SmartDiffbackup to DISK='C:\Temp\SmartDiffbackup.BAK';
GO


USE [SmartDiffbackup]
GO
UPDATE Tbl_SelectIntoTest
	SET DeptID = 5
WHERE RecordID%4=0
GO
UPDATE Tbl_SelectIntoTest
	SET City = 'San Jose'
WHERE RecordID%4=1
GO


USE [SmartDiffbackup]
GO
select CAST(ROUND((SUM(modified_extent_page_count)*100.0)/SUM(allocated_extent_page_count),2)
as decimal(9,2))
as '% Differential Changes since last backup'
from sys.dm_db_file_space_usage


--Take differential backup 
BACKUP DATABASE SmartDiffbackup
TO DISK='D:\SmartDiffbackup.DIF'
WITH DIFFERENTIAL;
GO

-- Differential backup doesn't reset the Diff bitmap or modified_extent_page_count counter 
USE [SmartDiffbackup]
GO
select CAST(ROUND((SUM(modified_extent_page_count)*100.0)/SUM(allocated_extent_page_count),2)
as decimal(9,2))
as '% Differential Changes since last backup'
from sys.dm_db_file_space_usage

--Take full database backup
BACKUP DATABASE SmartDiffbackup
TO DISK='D:\SmartDiffbackup_Second_Full.BAK';
GO


-- Full database backup resets Diff bitmap and modified_extent_page_count counter 
select CAST(ROUND((SUM(modified_extent_page_count)*100.0)/SUM(allocated_extent_page_count),2)
as decimal(9,2))
as '% Differential Changes since last backup'
from sys.dm_db_file_space_usage