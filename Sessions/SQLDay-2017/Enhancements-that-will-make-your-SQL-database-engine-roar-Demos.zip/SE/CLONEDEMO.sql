use master
go
drop database memoryoltp
go
create database memoryoltp
go
ALTER DATABASE memoryoltp ADD FILEGROUP memoryoltp_mod CONTAINS MEMORY_OPTIMIZED_DATA 
ALTER DATABASE memoryoltp ADD FILE (name='memoryoltp_mod1', filename='c:\temp\imoltp_mod1') TO FILEGROUP memoryoltp_mod 
ALTER DATABASE memoryoltp SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT=ON
GO
USE MemoryOLTP;
GO

-- Create a simple memory-optimized table 
CREATE TABLE dbo.Ord
   (OrdNo INTEGER not null PRIMARY KEY NONCLUSTERED, 
    OrdDate DATETIME not null, 
    CustCode NVARCHAR(5) not null) 
WITH (MEMORY_OPTIMIZED=ON);
GO

-- Enable Query Store before native module compilation
ALTER DATABASE MemoryOLTP SET QUERY_STORE = ON;
GO

-- Create natively compiled stored procedure
CREATE PROCEDURE dbo.OrderInsert(@OrdNo integer, @CustCode nvarchar(5))
WITH NATIVE_COMPILATION, SCHEMABINDING
AS 
    BEGIN ATOMIC WITH
    (TRANSACTION ISOLATION LEVEL = SNAPSHOT,
    LANGUAGE = N'English')

    DECLARE @OrdDate DATETIME = GETDATE();
    INSERT INTO dbo.Ord (OrdNo, CustCode, OrdDate) 
        VALUES (@OrdNo, @CustCode, @OrdDate);
END;
GO

use memoryoltp
go

-- Enable runtime stats collection for queries from dbo.OrderInsert stored procedure
DECLARE @db_id INT = DB_ID()
DECLARE @proc_id INT = OBJECT_ID('dbo.OrderInsert');
DECLARE @collection_enabled BIT;

EXEC [sys].[sp_xtp_control_query_exec_stats] @new_collection_value = 1, 
    @database_id = @db_id, @xtp_object_id = @proc_id;

-- Check the state of the collection flag
EXEC sp_xtp_control_query_exec_stats @database_id = @db_id, 
    @xtp_object_id = @proc_id, 
    @old_collection_value= @collection_enabled output;
SELECT @collection_enabled AS 'collection status';

-- Execute natively compiled workload
EXEC dbo.OrderInsert 1, 'A';
EXEC dbo.OrderInsert 2, 'B';
EXEC dbo.OrderInsert 3, 'C';
EXEC dbo.OrderInsert 4, 'D';
EXEC dbo.OrderInsert 5, 'E';
EXEC dbo.OrderInsert 6, 'F';
EXEC dbo.OrderInsert 7, 'G';
EXEC dbo.OrderInsert 8, 'H';
EXEC dbo.OrderInsert 9, 'I';

-- New executions
EXEC dbo.OrderInsert 10, 'J';
EXEC dbo.OrderInsert 11, 'K';
EXEC dbo.OrderInsert 12, 'L';


-- Check Query Store Data
-- Compile time data
SELECT q.query_id, plan_id, object_id, query_hash, cast (p.query_plan as xml),
    p.initial_compile_start_time, p.last_compile_start_time, 
    p.last_execution_time, p.avg_compile_duration,
    p.last_force_failure_reason, p.force_failure_count
FROM sys.query_store_query AS q
JOIN sys.query_store_plan AS p 
    ON q.query_id = p.plan_id
WHERE q.object_id = OBJECT_ID('dbo.OrderInsert');

-- Get runtime stats
-- Check count_executions field to verify that runtime statistics 
-- have been collected by the Query Store
SELECT qt.query_sql_text, q.query_id, p.plan_id, object_id, rsi.start_time, rsi.end_time,  
    cast(p.query_plan as xml), p.last_force_failure_reason, p.force_failure_count, rs.*
FROM sys.query_store_query_text qt
JOIN sys.query_store_query AS q
ON qt.query_text_id = q.query_text_id
JOIN sys.query_store_plan AS p 
    ON q.query_id = p.plan_id
JOIN sys.query_store_runtime_stats AS rs 
    ON rs.plan_id = p.plan_id
JOIN sys.query_store_runtime_stats_interval AS rsi 
    ON rs.runtime_stats_interval_id = rsi.runtime_stats_interval_id
--WHERE q.object_id = OBJECT_ID('dbo.OrderInsert');

DBCC CLONEDATABASE ([memoryoltp],[memoryoltp_clone])


SELECT @@VERSION
SELECT * FROM sys.dm_os_host_info

use [memoryoltp_clone]
GO

-- Check Query Store Data
-- Compile time data
SELECT q.query_id, plan_id, object_id, query_hash, cast (p.query_plan as xml),
    p.initial_compile_start_time, p.last_compile_start_time, 
    p.last_execution_time, p.avg_compile_duration,
    p.last_force_failure_reason, p.force_failure_count
FROM sys.query_store_query AS q
JOIN sys.query_store_plan AS p 
    ON q.query_id = p.plan_id
WHERE q.object_id = OBJECT_ID('dbo.OrderInsert');

-- Get runtime stats
-- Check count_executions field to verify that runtime statistics 
-- have been collected by the Query Store
SELECT qt.query_sql_text, q.query_id, p.plan_id, object_id, rsi.start_time, rsi.end_time,  
    cast(p.query_plan as xml), p.last_force_failure_reason, p.force_failure_count, rs.*
FROM sys.query_store_query_text qt
JOIN sys.query_store_query AS q
ON qt.query_text_id = q.query_text_id
JOIN sys.query_store_plan AS p 
    ON q.query_id = p.plan_id
JOIN sys.query_store_runtime_stats AS rs 
    ON rs.plan_id = p.plan_id
JOIN sys.query_store_runtime_stats_interval AS rsi 
    ON rs.runtime_stats_interval_id = rsi.runtime_stats_interval_id
--WHERE q.object_id = OBJECT_ID('dbo.OrderInsert');


exec sp_query_store_flush_db
DBCC CLONEDATABASE ([memoryoltp],[memoryoltp_clone_flushquerystore])

-- Check Query Store Data
-- Compile time data
SELECT q.query_id, plan_id, object_id, query_hash, cast (p.query_plan as xml),
    p.initial_compile_start_time, p.last_compile_start_time, 
    p.last_execution_time, p.avg_compile_duration,
    p.last_force_failure_reason, p.force_failure_count
FROM sys.query_store_query AS q
JOIN sys.query_store_plan AS p 
    ON q.query_id = p.plan_id
WHERE q.object_id = OBJECT_ID('dbo.OrderInsert');

-- Get runtime stats
-- Check count_executions field to verify that runtime statistics 
-- have been collected by the Query Store
SELECT qt.query_sql_text, q.query_id, p.plan_id, object_id, rsi.start_time, rsi.end_time,  
    cast(p.query_plan as xml), p.last_force_failure_reason, p.force_failure_count, rs.*
FROM sys.query_store_query_text qt
JOIN sys.query_store_query AS q
ON qt.query_text_id = q.query_text_id
JOIN sys.query_store_plan AS p 
    ON q.query_id = p.plan_id
JOIN sys.query_store_runtime_stats AS rs 
    ON rs.plan_id = p.plan_id
JOIN sys.query_store_runtime_stats_interval AS rsi 
    ON rs.runtime_stats_interval_id = rsi.runtime_stats_interval_id
--WHERE q.object_id = OBJECT_ID('dbo.OrderInsert');


DBCC CLONEDATABASE ([memoryoltp],[memoryoltp_schemaonlyclone]) WITH NO_QUERYSTORE,NO_STATISTICS

use [memoryoltp_schemaonlyclone]
GO
-- Check Query Store Data
-- Compile time data
SELECT q.query_id, plan_id, object_id, query_hash, cast (p.query_plan as xml),
    p.initial_compile_start_time, p.last_compile_start_time, 
    p.last_execution_time, p.avg_compile_duration,
    p.last_force_failure_reason, p.force_failure_count
FROM sys.query_store_query AS q
JOIN sys.query_store_plan AS p 
    ON q.query_id = p.plan_id
WHERE q.object_id = OBJECT_ID('dbo.OrderInsert');

-- Get runtime stats
-- Check count_executions field to verify that runtime statistics 
-- have been collected by the Query Store
SELECT qt.query_sql_text, q.query_id, p.plan_id, object_id, rsi.start_time, rsi.end_time,  
    cast(p.query_plan as xml), p.last_force_failure_reason, p.force_failure_count, rs.*
FROM sys.query_store_query_text qt
JOIN sys.query_store_query AS q
ON qt.query_text_id = q.query_text_id
JOIN sys.query_store_plan AS p 
    ON q.query_id = p.plan_id
JOIN sys.query_store_runtime_stats AS rs 
    ON rs.plan_id = p.plan_id
JOIN sys.query_store_runtime_stats_interval AS rsi 
    ON rs.runtime_stats_interval_id = rsi.runtime_stats_interval_id
--WHERE q.object_id = OBJECT_ID('dbo.OrderInsert');



--SELECT DATABASEPROPERTYEX('memoryoltp_clone','IsClone')
--ALTER DATABASE [memoryoltp_clone] SET READ_WRITE

