USE [Contoso_Main]
GO
CREATE OR ALTER PROCEDURE [Sales].[SalesFromDate] @StartOrderdate datetime 
AS 
SELECT *
FROM Sales.SalesOrderHeaderBulk AS h 
INNER JOIN Sales.SalesOrderDetailBulk AS d ON h.SalesOrderID = d.SalesOrderID
WHERE (h.OrderDate >= @StartOrderdate)
GO

--Original
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO
EXEC sp_executesql N'exec Sales.SalesFromDate @P1',N'@P1 datetime2(0)','2004-7-31 00:00:00'
GO
EXEC sp_executesql N'exec Sales.SalesFromDate @P1',N'@P1 datetime2(0)','2004-3-28 00:00:00'
GO

-- Compare both plans

USE [Contoso_Main]
GO
--Fix 1 - RECOMPILE
CREATE OR ALTER PROCEDURE Sales.SalesFromDate (@StartOrderdate datetime) AS 
SELECT * FROM Sales.SalesOrderHeaderBulk AS h 
INNER JOIN Sales.SalesOrderDetailBulk AS d ON h.SalesOrderID = d.SalesOrderID 
WHERE (h.OrderDate >= @StartOrderdate) 
OPTION (RECOMPILE)
GO

--Fix 2 - OPTIMIZE FOR
CREATE OR ALTER PROCEDURE Sales.SalesFromDate (@StartOrderdate datetime) AS 
SELECT * FROM Sales.SalesOrderHeaderBulk AS h 
INNER JOIN Sales.SalesOrderDetailBulk AS d ON h.SalesOrderID = d.SalesOrderID 
WHERE (h.OrderDate >= @StartOrderdate) 
--OPTION (OPTIMIZE FOR(@StartOrderDate = 'xxxx'))
OPTION (OPTIMIZE FOR UNKNOWN)
GO

--Fix 3 - local variable
CREATE OR ALTER PROCEDURE Sales.SalesFromDate (@StartOrderdate datetime) AS 
DECLARE @date datetime 
SELECT @date=@StartOrderDate 
SELECT * FROM Sales.SalesOrderHeaderBulk AS h 
INNER JOIN Sales.SalesOrderDetailBulk AS d ON h.SalesOrderID = d.SalesOrderID 
WHERE (h.OrderDate >= @date)
GO

--Fix 4 - USE HINT
CREATE OR ALTER PROCEDURE Sales.SalesFromDate (@StartOrderdate datetime) AS 
SELECT * FROM Sales.SalesOrderHeaderBulk AS h 
INNER JOIN Sales.SalesOrderDetailBulk AS d ON h.SalesOrderID = d.SalesOrderID 
WHERE (h.OrderDate >= @StartOrderdate) 
OPTION (USE HINT('DISABLE_PARAMETER_SNIFFING'))
GO


--Reset
CREATE OR ALTER PROCEDURE Sales.SalesFromDate (@StartOrderdate datetime) AS 
SELECT * FROM Sales.SalesOrderHeaderBulk AS h 
INNER JOIN Sales.SalesOrderDetailBulk AS d ON h.SalesOrderID = d.SalesOrderID 
WHERE (h.OrderDate >= @StartOrderdate) 
GO

