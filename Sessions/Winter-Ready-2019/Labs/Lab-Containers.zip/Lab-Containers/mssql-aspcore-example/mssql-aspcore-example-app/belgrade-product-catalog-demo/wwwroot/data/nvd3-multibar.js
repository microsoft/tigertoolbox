[
    {
        "key": "A Datum Corporation",
        "values": [
                    { "x": "Black", "y": 31.4900 },
                    { "x": "Magenta", "y": 100.0000 },
                    { "x": "Silver", "y": 359.9900 }
        ]
    },
    {
        "key": "Consolidated Messenger",
        "values": [
                    { "x": "Magenta", "y": 28.9900 },
                    { "x": "Red", "y": 41.9900 },
                    { "x": "White", "y": 120.9900 }
        ]
    }, {
        "key": "Contoso, Ltd.",
        "values": [
                    { "x": "White", "y": 560.9900 },
                    { "x": "Magenta", "y": 15.9900 },
                    { "x": "Black", "y": 299.0200 }
        ]
    }
]