[
        { "x": "Red", "y": 5 },
        { "x": "Silver", "y": 2 },
        { "x": "Black", "y": 9 },
        { "x": "Red", "y": 7 },
        { "x": "Magenta", "y": 4 },
        { "x": "White", "y": 3 },
        { "x": "Blue", "y": 0.5 }
]