sudo cp WideWorldImporters-Full.bak /var/opt/mssql
sudo chown mssql:mssql /var/opt/mssql/WideWorldImporters-Full.bak
