/opt/mssql-tools/bin/sqlcmd -Usa -irestorewwi_linux.sql
