-- *************************************************** --
-- Row mode MGF
-- *************************************************** --

-- Setup
ALTER DATABASE WideWorldImportersDW 
SET COMPATIBILITY_LEVEL = 150;
GO

ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO

USE WideWorldImportersDW;
GO

UPDATE STATISTICS [Fact].[Order] 
WITH ROWCOUNT = 1, PAGECOUNT = 1;
GO

CREATE OR ALTER PROCEDURE dbo.StockItems
AS
SELECT [Color], SUM([Quantity]) AS SumQty
FROM [Fact].[Order] AS [fo]
INNER JOIN [Dimension].[Stock Item] AS [si] 
	ON [fo].[Stock Item Key] = [si].[Stock Item Key]
GROUP BY  [Color];
GO

-- Run stored procedure
EXEC dbo.StockItems;

-- Cleanup
UPDATE STATISTICS Fact.OrderHistory 
WITH FULLSCAN;
GO


