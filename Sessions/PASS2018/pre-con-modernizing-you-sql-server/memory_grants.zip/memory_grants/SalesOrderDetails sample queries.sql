SELECT [SalesOrderID], [SalesOrderDetailID], [ProductID], [OrderQty]
, STR([UnitPrice] * [OrderQty]) AS [Line Total]
FROM [Sales].[SalesOrderDetail]
GO
SELECT [SalesOrderID], COUNT([SalesOrderDetailID]) AS [# Line Items], STR(SUM([UnitPrice] * [OrderQty])) AS [Sales Order Total]
FROM [Sales].[SalesOrderDetail]
GROUP BY SalesOrderID
GO
SELECT TOP 1000 
p.Name AS ProductName,  
NonDiscountSales = (OrderQty * UnitPrice),  
Discounts = ((OrderQty * UnitPrice) * UnitPriceDiscount)  
FROM Production.Product AS p  
INNER JOIN Sales.SalesOrderDetail AS sod ON p.ProductID = sod.ProductID  
ORDER BY ProductName DESC
OPTION (HASH JOIN --, min_grant_percent = 25
		)
GO
SELECT p.Name AS ProductName,
SUM(OrderQty * UnitPrice) as NonDiscountSales,
AVG((OrderQty * UnitPrice) * UnitPriceDiscount) as Discounts
FROM Production.Product AS p
INNER JOIN Sales.SalesOrderDetail AS sod ON p.ProductID = sod.ProductID
GROUP BY p.Name
ORDER BY p.Name DESC
OPTION (--HASH JOIN , -- min_grant_percent = 25
		USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION')
		)
GO
SELECT S.ProductID, p.[Name], S.SpecialOfferID, SO.[Description]
, COUNT([OrderQty]) AS [Count]
, (AVG(UnitPrice))AS [Average Price]
, STR(SUM(LineTotal)) AS SubTotal
FROM Sales.SalesOrderDetail AS S
INNER JOIN [Sales].[SpecialOffer] AS SO 
ON SO.[SpecialOfferID] = S.SpecialOfferID
INNER JOIN [Production].[Product] AS p ON p.[ProductID] = S.ProductID
GROUP BY S.ProductID, p.[Name], S.SpecialOfferID, SO.[Description]
ORDER BY S.ProductID, [Count] DESC
GO
SELECT p.ProductID, [Name], AVG([UnitPrice]) AS [Average List Price]
FROM Production.Product p
INNER JOIN [Sales].[SalesOrderDetail] s
ON p.ProductID = s.[ProductID]
GROUP BY p.ProductID, [Name]
Having AVG([UnitPrice]) > 1000 
ORDER BY p.ProductID
GO
SELECT sod.ProductID, AVG(sod.UnitPrice) AS [Average Price]
FROM Sales.SalesOrderDetail as sod
INNER JOIN Sales.SalesOrderHeader as soh
ON soh.SalesOrderID = sod.SalesOrderID
WHERE OrderQty > 10 AND YEAR(soh.OrderDate) = '2013' 
GROUP BY ProductID 
ORDER BY [Average Price] DESC
GO
SELECT ProductID, STR(SUM(LineTotal)) AS Total
FROM Sales.SalesOrderDetail
GROUP BY ProductID 
HAVING SUM(LineTotal) BETWEEN 1000000 AND 2000000
ORDER BY Total
GO
SELECT PC.Name AS Category, PS.Name AS Subcategory,
DATEPART(yy, SOH.OrderDate) AS [Year]
, 'Q' + DATENAME(qq, SOH.OrderDate) AS [Qtr]
, STR(SUM(DET.UnitPrice * DET.OrderQty)) AS [$ Sales]
FROM Production.ProductSubcategory AS PS
INNER JOIN Sales.SalesOrderHeader AS SOH 
INNER JOIN Sales.SalesOrderDetail DET ON SOH.SalesOrderID = DET.SalesOrderID
INNER JOIN Production.Product P ON DET.ProductID = P.ProductID
ON PS.ProductSubcategoryID = P.ProductSubcategoryID
INNER JOIN Production.ProductCategory PC ON PS.ProductCategoryID = PC.ProductCategoryID
WHERE YEAR(SOH.OrderDate) = '2012' or YEAR(SOH.OrderDate) ='2011'
GROUP BY DATEPART(yy, SOH.OrderDate), PC.Name, PS.Name, 'Q'
+ DATENAME(qq, SOH.OrderDate), PS.ProductSubcategoryID
ORDER BY Category, SubCategory, [Qtr]
GO

