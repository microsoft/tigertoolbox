-- view global memory grant status

SELECT * 
FROM sys.dm_exec_query_resource_semaphores
