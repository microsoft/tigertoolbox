CREATE EVENT SESSION [track_memory_grants] ON SERVER 
ADD EVENT sqlserver.additional_memory_grant(
    ACTION(sqlserver.client_app_name,sqlserver.query_hash_signed,sqlserver.query_plan_hash_signed,sqlserver.session_id,sqlserver.sql_text,sqlserver.tsql_frame)),
ADD EVENT sqlserver.excessive_non_grant_memory_used(
    ACTION(sqlserver.client_app_name,sqlserver.query_hash_signed,sqlserver.query_plan_hash_signed,sqlserver.session_id,sqlserver.sql_text,sqlserver.tsql_frame)),
ADD EVENT sqlserver.query_memory_grant_blocking(
    ACTION(sqlserver.client_app_name,sqlserver.query_hash_signed,sqlserver.query_plan_hash_signed,sqlserver.session_id,sqlserver.sql_text,sqlserver.tsql_frame)),
ADD EVENT sqlserver.query_memory_grant_usage(
    ACTION(sqlserver.client_app_name,sqlserver.query_hash_signed,sqlserver.query_plan_hash_signed,sqlserver.session_id,sqlserver.sql_text,sqlserver.tsql_frame)),
ADD EVENT sqlserver.query_memory_grant_wait_end(
    ACTION(sqlserver.client_app_name,sqlserver.query_hash_signed,sqlserver.query_plan_hash_signed,sqlserver.session_id,sqlserver.sql_text,sqlserver.tsql_frame)),
ADD EVENT sqlserver.sort_memory_grant_adjustment(
    ACTION(sqlserver.client_app_name,sqlserver.query_hash_signed,sqlserver.query_plan_hash_signed,sqlserver.session_id,sqlserver.sql_text,sqlserver.tsql_frame))
ADD TARGET package0.event_file(SET filename=N'F:\Program Files\Microsoft SQL Server\MSSQL13.SQL2016\MSSQL\Log\track_memory_grants.xel',max_file_size=(50),max_rollover_files=(0))
WITH (MAX_MEMORY=25600 KB,EVENT_RETENTION_MODE=ALLOW_MULTIPLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=PER_CPU,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO


