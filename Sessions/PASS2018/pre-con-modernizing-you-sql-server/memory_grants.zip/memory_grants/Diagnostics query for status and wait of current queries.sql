-- Get a quick view : status of requests and waits
-- use the loop for the sort spill scenario
--
SET NOCOUNT ON
GO
WHILE 1 = 1
BEGIN
SELECT 
er.session_id, er.status, er.wait_type, er.command, 
    SUBSTRING(st.text, (er.statement_start_offset/2)+1,   
        ((CASE er.statement_end_offset  
          WHEN -1 THEN DATALENGTH(st.text)  
         ELSE er.statement_end_offset  
         END - er.statement_start_offset)/2) + 1) AS statement_text,
mg.requested_memory_kb, mg.granted_memory_kb, mg.used_memory_kb
FROM sys.dm_exec_requests AS er
INNER JOIN sys.dm_exec_query_memory_grants AS mg ON er.session_id = mg.session_id
CROSS APPLY sys.dm_exec_sql_text(er.sql_handle) AS st 
WHERE er.session_id = 54
AND wait_type IS NOT NULL
WAITFOR DELAY '00:00:01'
END

-- Get a quick view : status of requests and waits
-- use the loop for the xml grants scenario
-- 
SELECT 
er.session_id, er.status, er.wait_type, er.command, 
    SUBSTRING(st.text, (er.statement_start_offset/2)+1,   
        ((CASE er.statement_end_offset  
          WHEN -1 THEN DATALENGTH(st.text)  
         ELSE er.statement_end_offset  
         END - er.statement_start_offset)/2) + 1) AS statement_text,
mg.requested_memory_kb, mg.granted_memory_kb, mg.used_memory_kb
FROM sys.dm_exec_requests AS er
INNER JOIN sys.dm_exec_query_memory_grants AS mg ON er.session_id = mg.session_id
CROSS APPLY sys.dm_exec_sql_text(er.sql_handle) AS st 
WHERE wait_type IS NOT NULL
ORDER BY mg.granted_memory_kb DESC
