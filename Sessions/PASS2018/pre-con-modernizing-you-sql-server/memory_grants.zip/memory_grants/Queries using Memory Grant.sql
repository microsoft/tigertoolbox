-- legacy versions clear cache
DBCC FREEPROCCACHE
GO
-- newer versions clear cache
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE
GO
-- clear query store info
ALTER DATABASE AdventureWorks SET QUERY_STORE CLEAR
GO
-- set database context
USE AdventureWorks
GO

-- Enable this option to see the worktable impact
SET STATISTICS IO ON
GO

-- Low grant query 
-- Inclue Actual execution plan and start SQL Trace / XE session
SELECT TOP 1000 
p.Name AS ProductName,  
NonDiscountSales = (OrderQty * UnitPrice),  
Discounts = ((OrderQty * UnitPrice) * UnitPriceDiscount)  
FROM Production.Product AS p  
INNER JOIN Sales.SalesOrderDetail AS sod ON p.ProductID = sod.ProductID  
ORDER BY ProductName DESC
OPTION (HASH JOIN)
GO

-- Try increasing the grant for this query in modern versions using query hint
SELECT TOP 1000 
p.Name AS ProductName,  
NonDiscountSales = (OrderQty * UnitPrice),  
Discounts = ((OrderQty * UnitPrice) * UnitPriceDiscount)  
FROM Production.Product AS p  
INNER JOIN Sales.SalesOrderDetail AS sod ON p.ProductID = sod.ProductID  
ORDER BY ProductName DESC
OPTION (HASH JOIN ,MIN_GRANT_PERCENT = 25)
GO

-- High grant query
-- Inclue Actual execution plan and start XE session
DECLARE @xml XML
DECLARE @x XML
SELECT @x = @xml.query('for $session in /conference/sessions, $speaker in $session/attendees  
return <UserID UserID= "{$session/@attendees }" >                  { $speaker/@code }                </UserID>      ')
GO

-- Adjust the grant using query hints in modern versions
DECLARE @xml XML
DECLARE @x XML
SELECT @x = @xml.query('for $session in /conference/sessions, $speaker in $session/attendees  
return <UserID UserID= "{$session/@attendees }" >                  { $speaker/@code }                </UserID>      ')
OPTION (min_grant_percent = 10, max_grant_percent = 50)
GO

-- wrapper to call this query as workload
CREATE PROCEDURE dbo.usp_Generate_SessionInfo
AS
BEGIN
DECLARE @xml XML
DECLARE @x XML
SELECT @x = @xml.query('for $session in /conference/sessions, $speaker in $session/attendees  
return <UserID UserID= "{$session/@attendees }" >                  { $speaker/@code }                </UserID>      ')
END
GO

-- wrapper to call this query as workload
CREATE PROCEDURE dbo.usp_Generate_ProductInfo
AS
BEGIN
SELECT TOP 1000 
p.Name AS ProductName,  
NonDiscountSales = (OrderQty * UnitPrice),  
Discounts = ((OrderQty * UnitPrice) * UnitPriceDiscount)  
FROM Production.Product AS p  
INNER JOIN Sales.SalesOrderDetail AS sod ON p.ProductID = sod.ProductID  
ORDER BY ProductName DESC
OPTION (HASH JOIN)
END
GO