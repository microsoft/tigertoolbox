-- get memory grant information from cached query stats
SELECT 
    SUBSTRING(st.text, (qs.statement_start_offset/2)+1,   
        ((CASE qs.statement_end_offset  
          WHEN -1 THEN DATALENGTH(st.text)  
         ELSE qs.statement_end_offset  
         END - qs.statement_start_offset)/2) + 1) AS statement_text ,
		 qs.last_grant_kb, qs.last_used_grant_kb
FROM sys.dm_exec_query_stats AS qs  
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st  
WHERE qs.query_hash IN ( 0x27CD6BF94514A388 , 0x27CD6BF94514A388 , 0xAAA1D6F29E2053CB , 0x60FED17AF16B93AB)
ORDER BY qs.last_execution_time DESC
GO
-- these stats will disappear when the plans disappear from the cache
--ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
--GO

USE AdventureWorks
GO
-- get memory grant information from query store
SELECT rsi.end_time, qt.query_sql_text,
rs.last_query_max_used_memory*8 as last_memgrant_kb, 
rs.avg_query_max_used_memory*8 as avg_memgrant_kb, 
rs.max_query_max_used_memory*8 as max_memgrant_kb   
FROM sys.query_store_query_text AS qt   
JOIN sys.query_store_query AS q   
    ON qt.query_text_id = q.query_text_id   
JOIN sys.query_store_plan AS p   
    ON q.query_id = p.query_id   
JOIN sys.query_store_runtime_stats AS rs   
    ON p.plan_id = rs.plan_id  
JOIN sys.query_store_runtime_stats_interval AS rsi
	ON rs.runtime_stats_interval_id = rsi.runtime_stats_interval_id
WHERE q.query_hash IN ( 0x27CD6BF94514A388 , 0x27CD6BF94514A388 , 0xAAA1D6F29E2053CB , 0x60FED17AF16B93AB)
ORDER BY rsi.end_time DESC
GO

-- clear query store stats
--ALTER DATABASE AdventureWorks SET QUERY_STORE CLEAR
--GO