-- view current workload settings
SELECT name, request_max_memory_grant_percent
FROM sys.resource_governor_workload_groups
GO

-- adjust workload group settings
ALTER WORKLOAD GROUP [default]
WITH (REQUEST_MAX_MEMORY_GRANT_PERCENT = 10);  
GO  
ALTER RESOURCE GOVERNOR RECONFIGURE;  
GO  

-- reset workload group settings to default
ALTER WORKLOAD GROUP [default]
WITH (REQUEST_MAX_MEMORY_GRANT_PERCENT = 25);  
GO  
ALTER RESOURCE GOVERNOR RECONFIGURE;  
GO  
