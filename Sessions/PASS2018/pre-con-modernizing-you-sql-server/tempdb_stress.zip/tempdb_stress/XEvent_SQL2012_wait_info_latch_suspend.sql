CREATE EVENT SESSION [track_waits] ON SERVER 
ADD EVENT sqlos.wait_info(
    ACTION(package0.callstack,sqlserver.client_app_name,sqlserver.session_id,sqlserver.tsql_frame)
    WHERE (([wait_type]=(52) OR [wait_type]=(51) OR [wait_type]=(51)) AND [duration]>(0) AND [opcode]=(1)))
ADD TARGET package0.event_file(SET filename=N'track_waits',max_file_size=(25),max_rollover_files=(0))
WITH (MAX_MEMORY=25 MB,EVENT_RETENTION_MODE=ALLOW_MULTIPLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=PER_CPU,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

CREATE EVENT SESSION [track_latch] ON SERVER 
ADD EVENT sqlserver.latch_suspend_end(
    ACTION(package0.callstack,sqlserver.client_app_name,sqlserver.session_id,sqlserver.tsql_frame)
    WHERE ([duration]>(0) AND [class]=(28) AND ([mode]=(2) OR [mode]=(4) OR [mode]=(3))))
ADD TARGET package0.event_file(SET filename=N'track_latch',max_file_size=(25),max_rollover_files=(0))
WITH (MAX_MEMORY=25 MB,EVENT_RETENTION_MODE=ALLOW_MULTIPLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=PER_CPU,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO




