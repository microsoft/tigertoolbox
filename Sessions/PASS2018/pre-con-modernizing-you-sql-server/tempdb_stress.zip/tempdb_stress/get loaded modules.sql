select name,base_address from sys.dm_os_loaded_modules
