-- get current executing statement from tsql frame in XEvent

DECLARE @tsql_frame xml
SET @tsql_frame = '<frame level="1" handle="0x030005000D42C5376639A20088A9000001000000000000000000000000000000000000000000000000000000" line="4" offsetStart="102" offsetEnd="798" />'

DECLARE @handle varbinary(64) 
SELECT @handle = CONVERT(varbinary(64), @tsql_frame.value('(./frame/@handle)[1]','varchar(255)'),1)
DECLARE @offsetStart int
SELECT @offsetStart = @tsql_frame.value('(./frame/@offsetStart)[1]','int')
DECLARE @offsetEnd int
SELECT @offsetEnd = @tsql_frame.value('(./frame/@offsetEnd)[1]','int')

SELECT   
    SUBSTRING(st.text, (@offsetStart/2)+1,   
        ((CASE @offsetEnd  
          WHEN -1 THEN DATALENGTH(st.text)  
         ELSE @offsetEnd  
         END - @offsetStart)/2) + 1) AS statement_text  
FROM sys.dm_exec_sql_text(@handle) AS st 
