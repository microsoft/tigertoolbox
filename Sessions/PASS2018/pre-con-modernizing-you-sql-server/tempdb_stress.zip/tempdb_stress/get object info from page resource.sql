-- Decode the wait resource to an object
declare @wait_resource nvarchar(255) = '2:1:126'
declare @ObjectId nvarchar(50)
declare @dbid nvarchar(50), @fileid nvarchar(50), @pageid nvarchar(50)
set @dbid = substring(@wait_resource, 1, charindex (':', @wait_resource) - 1) 
set @fileid = substring(@wait_resource , charindex( ':', @wait_resource) + 1, charindex(':', @wait_resource, charindex(':', @wait_resource) + 1) - charindex(':',@wait_resource) - 1) 
set @pageid = substring(@wait_resource, charindex(':', @wait_resource, charindex(':', @wait_resource, charindex(':', @wait_resource) + 1)) + 1, len(@wait_resource) - (charindex(':', @wait_resource, charindex(':', @wait_resource, charindex(':', @wait_resource) + 1)) - 1) ) 
declare @pageinfo table 
(
[ParentObject]	nvarchar(255),
[Object]		nvarchar(255),
[Field]			nvarchar(255),
[VALUE]			nvarchar(255)
)
declare @cmd nvarchar(255) = 'dbcc page ( ' + @dbid + ' , ' + @fileid + ' , ' + @pageid + ' , 0 ) with tableresults'
insert into @pageinfo exec ( @cmd )
select @ObjectId = [VALUE] from @pageinfo where [Field] = 'Metadata: ObjectId'
select @ObjectId as "Object ID" , OBJECT_NAME(@ObjectId,2) as "Object Name"
go

-- Other ways to map page id to object id

--SELECT allocated_page_file_id, allocated_page_page_id, [object_id], index_id, OBJECT_NAME([object_id],2) as "Object_Name" 
--FROM sys.dm_db_database_page_allocations(2,NULL,NULL,NULL,'LIMITED') 
--WHERE allocated_page_file_id = 1 AND allocated_page_page_id = 126
--GO

--SELECT 
--bd.database_id, bd.[file_id], bd.page_id, p.[object_id], p.index_id, OBJECT_NAME(p.[object_id],bd.database_id) as "Object_Name" 
--FROM sys.dm_os_buffer_descriptors bd
--LEFT OUTER JOIN tempdb.sys.allocation_units au on bd.allocation_unit_id = au.allocation_unit_id
--LEFT OUTER JOIN tempdb.sys.partitions p ON ((au.container_id = p.hobt_id) AND (au.type = 1 OR au.type = 3)) OR ((au.container_id = p.partition_id) AND au.type = 2)
--WHERE bd.database_id = 2 and bd.[file_id]=1 and bd.[page_id] = 120
--GO