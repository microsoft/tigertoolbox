CREATE EVENT SESSION [track_waits_nonoptimized] ON SERVER 
ADD EVENT sqlos.wait_completed(
    ACTION(package0.callstack,sqlserver.client_app_name,sqlserver.session_id,sqlserver.tsql_frame)
    WHERE ([duration]>(0) AND ([wait_type]=(50) OR [wait_type]=(51) OR [wait_type]=(52))))
ADD TARGET package0.event_file(SET filename=N'track_waits_nonoptimized',max_file_size=(25),max_rollover_files=(0))
WITH (MAX_MEMORY=16384 KB,EVENT_RETENTION_MODE=ALLOW_MULTIPLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=PER_CPU,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

CREATE EVENT SESSION [track_waits_optimized] ON SERVER 
ADD EVENT sqlos.wait_completed(
    ACTION(package0.callstack,sqlserver.client_app_name,sqlserver.session_id,sqlserver.tsql_frame)
    WHERE ([duration]>(0) AND ([wait_type]=(50) OR [wait_type]=(51) OR [wait_type]=(52))))
ADD TARGET package0.event_file(SET filename=N'track_waits_optimized',max_file_size=(25),max_rollover_files=(0))
WITH (MAX_MEMORY=16384 KB,EVENT_RETENTION_MODE=ALLOW_MULTIPLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=PER_CPU,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO
