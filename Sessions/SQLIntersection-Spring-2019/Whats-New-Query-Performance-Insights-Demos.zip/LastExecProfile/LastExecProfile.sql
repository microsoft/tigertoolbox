DBCC TRACEON(2451, -1)
DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS
GO

SELECT * FROM sys.dm_os_memory_clerks
WHERE [type] = 'MEMORYCLERK_QUERYPROFILE';
GO
SELECT * FROM sys.dm_os_memory_objects
WHERE [type] = 'MEMOBJ_PROFILECONTEXT';
GO

USE [AdventureWorksDW2016_EXT]
GO
-- Cacheable
SELECT TOP 1000 * 
FROM [dbo].[DimProduct] AS dp
INNER JOIN [dbo].[DimProductCategory] AS dpc ON dp.ProductSubcategoryKey = dpc.ProductCategoryKey
WHERE dp.ProductKey BETWEEN 300 AND 400;
GO
-- Non-Cacheable
SELECT TOP 1000 * 
FROM [dbo].[DimProduct] AS dp
INNER JOIN [dbo].[DimProductCategory] AS dpc ON dp.ProductSubcategoryKey = dpc.ProductCategoryKey;
GO

SELECT *   
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS st
CROSS APPLY sys.dm_exec_query_plan_stats(plan_handle) AS qps
WHERE st.text LIKE '--%';
GO

DBCC TRACEOFF(2451, -1)
DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS
GO

ALTER DATABASE SCOPED CONFIGURATION SET LAST_QUERY_PLAN_STATS = ON;
GO

USE [AdventureWorksDW2016_EXT]
GO
-- Cacheable
SELECT TOP 1000 * 
FROM [dbo].[DimProduct] AS dp
INNER JOIN [dbo].[DimProductCategory] AS dpc ON dp.ProductSubcategoryKey = dpc.ProductCategoryKey
WHERE dp.ProductKey BETWEEN 300 AND 400;
GO
-- Non-cacheable
SELECT TOP 1000 * 
FROM [dbo].[DimProduct] AS dp
INNER JOIN [dbo].[DimProductCategory] AS dpc ON dp.ProductSubcategoryKey = dpc.ProductCategoryKey;
GO

SELECT *   
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS st
CROSS APPLY sys.dm_exec_query_plan_stats(plan_handle) AS qps
WHERE st.text LIKE '--%';
GO