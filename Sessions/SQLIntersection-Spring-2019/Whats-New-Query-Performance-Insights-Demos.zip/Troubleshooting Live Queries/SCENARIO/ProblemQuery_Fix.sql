USE AdventureWorks2016_EXT
GO
CREATE NONCLUSTERED INDEX [IX_ProductID] ON [Sales].[SalesOrderDetailBulk] ([ProductID])
INCLUDE ([OrderQty],[UnitPrice],[UnitPriceDiscount])
GO


-- I'm on 2019, so can I do more?
ALTER DATABASE [AdventureWorks2016_EXT] SET COMPATIBILITY_LEVEL = 150
GO