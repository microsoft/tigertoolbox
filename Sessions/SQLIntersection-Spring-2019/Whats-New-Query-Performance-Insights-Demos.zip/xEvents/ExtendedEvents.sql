-- LWP related extended events Demo

DROP EVENT SESSION [PerfStats_Node] ON SERVER 
GO

CREATE EVENT SESSION [PerfStats_Node] ON SERVER
ADD EVENT sqlserver.query_thread_profile(
ACTION(sqlos.scheduler_id,sqlserver.database_id,sqlserver.is_system,sqlserver.plan_handle,sqlserver.query_hash_signed,sqlserver.query_plan_hash_signed,sqlserver.server_instance_name,sqlserver.session_id,sqlserver.session_nt_username,sqlserver.sql_text))
--ADD TARGET package0.ring_buffer(SET max_memory=(25600))
ADD TARGET package0.event_file(SET filename=N'C:\Temp\PerfStats_Node.xel',max_file_size=(50),max_rollover_files=(2))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

USE AdventureWorks2016_EXT
GO

DBCC DROPCLEANBUFFERS
GO

ALTER EVENT SESSION [PerfStats_Node] ON SERVER STATE = start;  
GO  

SELECT COUNT(*)
FROM Sales.SalesOrderDetail AS sod
INNER JOIN Sales.SalesOrderHeader AS soh ON soh.SalesOrderID = sod.SalesOrderID
GROUP BY soh.Status;
GO

ALTER EVENT SESSION [PerfStats_Node] ON SERVER STATE = stop;  
GO 

-- Choose any event and let's open the associated cached plan.
-- I want to see which operator this one is, and where in the plan it sits

SELECT qp.query_plan 
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) qp
WHERE CAST(qs.query_plan_hash AS BIGINT) = -4407577682464253461;
GO

-- How will I search for my node_id? Use showplan search in SSMS.

-------------------------------

-- Now for other new events. 
-- LWP-based "query_post_execution_showplan" for single query

DROP EVENT SESSION [PerfStats_LWP_Plan_Single] ON SERVER 
GO
CREATE EVENT SESSION [PerfStats_LWP_Plan_Single] ON SERVER
ADD EVENT sqlserver.query_plan_profile(
ACTION(sqlos.scheduler_id,sqlserver.database_id,sqlserver.is_system,sqlserver.plan_handle,sqlserver.query_hash_signed,sqlserver.query_plan_hash_signed,sqlserver.server_instance_name,sqlserver.session_id,sqlserver.session_nt_username,sqlserver.sql_text))
--ADD TARGET package0.ring_buffer(SET max_memory=(25600))
ADD TARGET package0.event_file(SET filename=N'C:\Temp\PerfStats_LWP_Plan_Single.xel',max_file_size=(50),max_rollover_files=(2))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

-- Let's create a sproc
CREATE OR ALTER PROCEDURE [Sales].[CountSalesOrderByStatus]
AS
SELECT COUNT(*)
FROM Sales.SalesOrderDetail AS sod
INNER JOIN Sales.SalesOrderHeader AS soh 
	ON soh.SalesOrderID = sod.SalesOrderID
GROUP BY soh.Status;
GO

-- and a plan guide with the required hint

EXEC sp_control_plan_guide N'DROP', N'Guide1';  
GO

EXEC sp_create_plan_guide   
@name = N'Guide1',  
@stmt = 'SELECT COUNT(*)
FROM Sales.SalesOrderDetail AS sod
INNER JOIN Sales.SalesOrderHeader AS soh 
	ON soh.SalesOrderID = sod.SalesOrderID
GROUP BY soh.Status;',  
@type = N'OBJECT',  
@module_or_batch = N'Sales.CountSalesOrderByStatus',  
@params = NULL,  
@hints = N'OPTION (USE HINT (''QUERY_PLAN_PROFILE''))';
GO

DBCC DROPCLEANBUFFERS
GO

ALTER EVENT SESSION [PerfStats_LWP_Plan_Single] ON SERVER STATE = start;  
GO   

EXEC Sales.CountSalesOrderByStatus;
GO

ALTER EVENT SESSION [PerfStats_LWP_Plan_Single] ON SERVER STATE = stop;  
GO 

-- Let's see the event and what it provides

-- If on SQL 2019, repeat after enablinh TF 7415 to allow I/O stats to be collected.

DBCC TRACEON (7415, -1);
GO

-------------------------------

-- Now for a new event. A LWP-based "query_post_execution_showplan" for all queries

DROP EVENT SESSION [PerfStats_LWP_Plan_All] ON SERVER 
GO
CREATE EVENT SESSION [PerfStats_LWP_Plan_All] ON SERVER
ADD EVENT sqlserver.query_post_execution_plan_profile(
ACTION(sqlos.scheduler_id,sqlserver.database_id,sqlserver.is_system,sqlserver.plan_handle,sqlserver.query_hash_signed,sqlserver.query_plan_hash_signed,sqlserver.server_instance_name,sqlserver.session_id,sqlserver.session_nt_username,sqlserver.sql_text))
--ADD TARGET package0.ring_buffer(SET max_memory=(25600))
ADD TARGET package0.event_file(SET filename=N'C:\Temp\PerfStats_LWP_Plan_All.xel',max_file_size=(50),max_rollover_files=(2))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

DBCC DROPCLEANBUFFERS
GO

ALTER EVENT SESSION [PerfStats_LWP_Plan_All] ON SERVER STATE = start;  
GO   

-- Let's run the following query
SELECT COUNT(*)
FROM Sales.SalesOrderDetail AS sod
INNER JOIN Sales.SalesOrderHeader AS soh 
	ON soh.SalesOrderID = sod.SalesOrderID
GROUP BY soh.Status;
GO

ALTER EVENT SESSION [PerfStats_LWP_Plan_All] ON SERVER STATE = stop;  
GO 

-- Let's see the event and what it provides

-------------------------------

-- Now for standard profiling event query_post_execution_showplan

DROP EVENT SESSION [PerfStats_Std_Plan_All] ON SERVER 
GO
CREATE EVENT SESSION [PerfStats_Std_Plan_All] ON SERVER
ADD EVENT sqlserver.query_post_execution_showplan(
ACTION(sqlos.scheduler_id,sqlserver.database_id,sqlserver.is_system,sqlserver.plan_handle,sqlserver.query_hash_signed,sqlserver.query_plan_hash_signed,sqlserver.server_instance_name,sqlserver.session_id,sqlserver.session_nt_username,sqlserver.sql_text))
--ADD TARGET package0.ring_buffer(SET max_memory=(25600))
ADD TARGET package0.event_file(SET filename=N'C:\Temp\Std_Plan_All.xel',max_file_size=(50),max_rollover_files=(2))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

DBCC DROPCLEANBUFFERS
GO

ALTER EVENT SESSION [PerfStats_Std_Plan_All] ON SERVER STATE = start;  
GO   

-- Let's run the following query
SELECT COUNT(*)
FROM Sales.SalesOrderDetail AS sod
INNER JOIN Sales.SalesOrderHeader AS soh 
	ON soh.SalesOrderID = sod.SalesOrderID
GROUP BY soh.Status;
GO

ALTER EVENT SESSION [PerfStats_Std_Plan_All] ON SERVER STATE = stop;  
GO 

-- Let's see the event and what it provides